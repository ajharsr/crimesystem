package com.Crime.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.Crime.constant.Constant;
import com.Crime.model.CrimeModel;
import com.Crime.util.DbConnection;

public class ViewCrimeDao {

	static Connection con = null;
	static String sql = null;
	static PreparedStatement pst;
	static ResultSet rst;
	
	public static Connection getConnection() {

		try {
			System.out.println("inside Apponitment dao conenction");
			Class.forName(Constant.DRIVER);
			con = DriverManager.getConnection(Constant.URL, Constant.USERNAME, Constant.PASSWORD);
		} catch (Exception e) {
			e.printStackTrace();
			System.err.println(e);
		}
		return con;
	}

	public static CrimeModel getRecordbyEmail(String email) {
		CrimeModel crimemodel = new CrimeModel();
		try {
			System.out.println("inside AddRegistration save try ");
			con = getConnection();
			sql = Constant.VIEWCRIME;
			pst = con.prepareStatement(sql);
			pst.setString(1, email);
			rst = pst.executeQuery();
			while (rst.next()) {
				crimemodel.setId(rst.getInt(1));
				crimemodel.setName(rst.getString(2));
				crimemodel.setEmail(rst.getString(3));
				crimemodel.setMobile(rst.getLong(4));
				crimemodel.setGender(rst.getString(5));
				crimemodel.setAddress(rst.getString(6));
				crimemodel.setState(rst.getString(7));
				crimemodel.setCity(rst.getString(8));
				crimemodel.setZip(rst.getInt(9));
				crimemodel.setAbout(rst.getString(10));
				crimemodel.setFileName(rst.getString(11));
				crimemodel.setPath(rst.getString(12));
			}

		} catch (Exception ex) {
			System.out.println("inside crimemodel get record by email catch");
			ex.printStackTrace();
			System.out.println(ex);
		}

		return crimemodel;

	}

}
