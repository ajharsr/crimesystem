package com.Crime.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.Crime.constant.Constant;
import com.Crime.model.CrimeModel;
import com.Crime.model.Firmodel;

public class ViewFirDao {
	static Connection con = null;
	static String sql = null;
	static PreparedStatement pst;
	static ResultSet rst;
	
	public static Connection getConnection() {

		try {
			System.out.println("inside Apponitment dao conenction");
			Class.forName(Constant.DRIVER);
			con = DriverManager.getConnection(Constant.URL, Constant.USERNAME, Constant.PASSWORD);
		} catch (Exception e) {
			e.printStackTrace();
			System.err.println(e);
		}
		return con;
	}
	public static Firmodel getRecordbyEmail(String email) {
		Firmodel firmodel = new Firmodel();
		try {
			System.out.println("inside firmodel save try ");
			con = getConnection();
			sql = Constant.VIEWFIR;
			pst = con.prepareStatement(sql);
			pst.setString(1, email);
			rst = pst.executeQuery();
			while (rst.next()) {
			firmodel.setId(rst.getInt(1));
			firmodel.setName(rst.getString(2));
			firmodel.setFname(rst.getString(3));
			firmodel.setLname(rst.getString(4));
			firmodel.setAddress(rst.getString(5));
			firmodel.setGender(rst.getString(6));
			firmodel.setState(rst.getString(7));
			firmodel.setCity(rst.getString(8));
			firmodel.setDob(rst.getString(9));
			firmodel.setPincode(rst.getInt(10));
			firmodel.setType(rst.getString(11));
			firmodel.setEmail(rst.getString(12));
			firmodel.setMobile(rst.getLong(13));
			firmodel.setOthers(rst.getString(14));
			
			
			}
		} catch (Exception ex) {
			System.out.println("inside firmodel get record by email catch");
			ex.printStackTrace();
			System.out.println(ex);
		}

		return firmodel;

	}

}