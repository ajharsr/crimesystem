package com.Crime.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import com.Crime.constant.Constant;
import com.Crime.model.Registration;

public class SessionDao {
	private Connection con;
	private ResultSet rst;
	private String sql;
	private PreparedStatement pst;

	public SessionDao(Connection con) {
		super();
		this.con = con;
	}

	public Registration getUserByEmail(String email) {
		Registration registration = null;
		System.out.println("inside session  block ");
		try {
			System.out.println("inside session try block ");
			sql = Constant.SESSION;
			pst = con.prepareStatement(sql);
			pst.setString(1, email);
			rst = pst.executeQuery();
				if(rst.next()) {
					registration = new Registration();
					System.out.println("inside session if  block ");
					registration.setId(rst.getLong("id"));
					registration.setEmail(rst.getString("email"));
					registration.setName(rst.getString("name"));
					registration.setPassword(rst.getString("password"));
				}else {
					System.out.println("inside session else  block ");	
				}
		} catch (Exception ex) {
			System.out.println("inside session catch block ");
			ex.printStackTrace();
			System.out.println(ex);
		}

		return registration;

	}
}
