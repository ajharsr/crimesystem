package com.Crime.service;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.Crime.constant.Constant;
import com.Crime.model.CrimeModel;
import com.Crime.util.DbConnection;

public class EditCrime {
	static Connection con = null;
	static String sql = null;
	static PreparedStatement pst;

	public static int updateCrime(CrimeModel crime) {

		System.out.println("InsideUpdateAppoitment service");
		int status = 0;
		System.out.println("status " + status);
		try {
			System.out.println("inside updateCrime save try ");
			con = DbConnection.GetConnection();
			sql = Constant.UPDATECRIME;
			pst = con.prepareStatement(sql);
			pst.setString(1, crime.getName());
			pst.setString(2, crime.getEmail());
			pst.setLong(2, crime.getMobile());
			pst.setString(3, crime.getGender());
			pst.setString(4, crime.getAddress());
			pst.setString(5, crime.getState());
			pst.setString(6, crime.getCity());
			pst.setInt(7, crime.getZip());
			pst.setString(8, crime.getAbout());
			pst.setString(9, crime.getFileName());
			pst.setString(10, crime.getPath());
			pst.setString(11, crime.getEmail());
			status = pst.executeUpdate(); // 1
			System.out.println("finale status " + status);
		} catch (Exception ex) {
			System.out.println("inside AddRegistration save catch ");
			ex.printStackTrace();
			System.out.println(ex);
		}
		return status;
	}

}
