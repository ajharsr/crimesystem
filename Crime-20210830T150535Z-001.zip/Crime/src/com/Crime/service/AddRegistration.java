package com.Crime.service;
import java.sql.Connection;
import java.sql.PreparedStatement;
import com.Crime.constant.Constant;
import com.Crime.model.Registration;
import com.Crime.util.DbConnection;
public class AddRegistration {
	static Connection con = null;
	static String sql = null;
	static PreparedStatement pst;
	// method to save  registration //
	public static int Save(Registration registration) { //0 //1
		int status = 0 ; //0
		System.out.println("intial status "+ status);
		try {
			System.out.println("inside AddRegistration save try ");
			con =DbConnection.GetConnection();
			sql = Constant.REGISTER;
			pst = con.prepareStatement(sql);
			pst.setString(1, registration.getName());
			pst.setString(2, registration.getEmail());
			pst.setString(3, registration.getPassword());
			pst.setString(4, registration.getCpassword());
			status = pst.executeUpdate(); //1
			System.out.println("finale status "+status);
		}catch(Exception ex ) {
			System.out.println("inside AddRegistration save catch ");
			ex.printStackTrace();
			System.out.println(ex);
		}
		return status;
	}
	// method to save  registration  end //
}

