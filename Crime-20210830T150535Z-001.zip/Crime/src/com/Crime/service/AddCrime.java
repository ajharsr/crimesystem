package com.Crime.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.Crime.constant.Constant;
import com.Crime.model.CrimeModel;

import com.Crime.util.DbConnection;

public class AddCrime {
	 static Connection con;
	 static ResultSet rst;
	 static String sql;
	 static PreparedStatement pst;
	
	
	
	public static int SaveCrime(CrimeModel crime) { //0 //1
		int status = 0 ; //0
		System.out.println("intial status "+ status);
		try {
			System.out.println("inside AddRegistration save try ");
			con =DbConnection.GetConnection();
			sql = Constant.crime;
			pst = con.prepareStatement(sql);
			pst.setString(1, crime.getName());
			pst.setString(2, crime.getEmail());
			pst.setLong(3, crime.getMobile());
			pst.setString(4, crime.getGender());
			pst.setString(5, crime.getAddress());
			pst.setString(6, crime.getState());
			pst.setString(7, crime.getCity());
			pst.setInt(8, crime.getZip());
			pst.setString(9, crime.getAbout());
			pst.setString(10, crime.getFileName());
			pst.setString(11, crime.getPath());
			status = pst.executeUpdate(); //1
			System.out.println("finale status "+status);
		}catch(Exception ex ) {
			System.out.println("inside AddRegistration save catch ");
			ex.printStackTrace();
			System.out.println(ex);
		}
		return status;
	}

}
