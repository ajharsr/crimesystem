package com.Crime.service;
import java.sql.Connection;
import java.sql.PreparedStatement;

import com.Crime.constant.Constant;
import com.Crime.model.Firmodel;
import com.Crime.util.DbConnection;
public class AddFir {
	static Connection con = null;
	static String sql = null;
	static PreparedStatement pst;
	// to save fir //
		public static int saveFir(Firmodel firmodel) {
			System.out.println("inside save fir");
			int status = 0 ;
			System.out.println("intial status = " + status);
			try {
				System.out.println("Inside save fir try");
				con = DbConnection.GetConnection();
				sql = Constant.FIR;
				pst=con.prepareStatement(sql);
				pst.setString(1, firmodel.getName());
				pst.setString(2, firmodel.getFname());
				pst.setString(3, firmodel.getLname());
				pst.setString(4, firmodel.getAddress());
				pst.setString(5, firmodel.getGender());
				pst.setString(6, firmodel.getState());
				pst.setString(7, firmodel.getCity());
				pst.setString(8, firmodel.getDob());
				pst.setInt(9, firmodel.getPincode());
				pst.setString(10, firmodel.getType());
				pst.setString(11, firmodel.getEmail());
				pst.setLong(12, firmodel.getMobile());
				pst.setString(13, firmodel.getOthers());
				status = pst.executeUpdate();
				System.out.println("final staus = "+ status);
			}catch (Exception e) {
				System.out.println("Inside save fir catch");
				e.printStackTrace();
				System.err.println(e);
			}
			return status;
		}
	
	// to save fir end //

}
