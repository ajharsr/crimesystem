package com.Crime.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.Crime.constant.Constant;
import com.Crime.util.DbConnection;

public class LoginValdition {
	
	static Connection con = null;
	static String sql = null;
	static PreparedStatement pst;
	static ResultSet rst;
	public static boolean LoginValdition(String email, String password) {
		boolean flag = false;
		try {
			System.out.println("inside Loginvaldtion try block");
			con = DbConnection.GetConnection();
			sql = Constant.SIGININ;
			pst = con.prepareStatement(sql);
			pst.setString(1, email);
			pst.setString(2, password);
			rst = pst.executeQuery();
			flag = rst.next();
		}catch(Exception ex) {
			System.out.println("inside Loginvaldtion catch block");
			ex.printStackTrace();
			System.out.println(ex);
		}finally {
			
		}try {
			System.out.println("inside Loginvaldtion finally try block");
			con.close();
		}catch(Exception ex) {
			System.out.println("inside Loginvaldtion finally catch block");
			ex.printStackTrace();
			System.out.println(ex);
		}
		return flag;
		
	}
	
}
