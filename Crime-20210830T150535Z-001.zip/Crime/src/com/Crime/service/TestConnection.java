package com.Crime.service;


import java.sql.Connection;

import com.Crime.util.DbConnection;

public class TestConnection {
	
	public static void main(String[] args) {
		try {
			Connection con = DbConnection.GetConnection();
			System.out.println(con);
			
		}catch (Exception e) {
			// TODO: handle exception
		}
	}

}
