package com.Crime.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.Crime.model.Registration;
import com.Crime.service.AddRegistration;

@WebServlet("/Register")
public class Register extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out = response.getWriter();
		String name = request.getParameter("name");
		String email = request.getParameter("email");
		String password = request.getParameter("password");
		String cpassword = request.getParameter("cpassword");
		// console check
		System.out.println(name);
		System.out.println(email);
		System.out.println(password);
		System.out.println(cpassword);
		Registration registration = new Registration();
		try {
			System.out.println("inside registraion try block");
			registration.setName(name);
			registration.setEmail(email);
			registration.setPassword(password);
			registration.setCpassword(cpassword);
		} catch (Exception ex) {
			System.out.println("inside registraion catch block");
			ex.printStackTrace();
			System.out.println(ex);
		}
		try {
			System.out.println("inside registraion try2 block");
			int status = AddRegistration.Save(registration);
			if (status > 0) {
				System.out.println("inside  save if  block");
				request.getRequestDispatcher("index.html").include(request, response);
			} else {
				System.out.println("inside  save else  block");
			}
		} catch (Exception ex) {
			System.out.println("inside registraion catch2 block");
			ex.printStackTrace();
			System.out.println(ex);
		}
	}
}
