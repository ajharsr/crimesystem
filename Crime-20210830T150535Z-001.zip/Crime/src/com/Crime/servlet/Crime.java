package com.Crime.servlet;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import com.Crime.model.CrimeModel;
import com.Crime.service.AddCrime;

@WebServlet("/Crime")
@MultipartConfig(fileSizeThreshold = 1024 * 1024 * 10, // 10 MB
maxFileSize = 1024 * 1024 * 1000, // 1 GB
maxRequestSize = 1024 * 1024 * 1000)   	// 1 GB
public class Crime extends HttpServlet {
	ServletOutputStream os;
	@Override
  	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		os = response.getOutputStream();
		
		// file upload // 
		  String folderName = "files";
      //  String uploadPath = request.getServletContext().getRealPath("/") + File.separator + folderName;//for netbeans use this code
         String uploadPath = request.getServletContext().getRealPath("") + folderName;// for eclipse use this code
         File dir = new File(uploadPath);
         if (!dir.exists()) {
             dir.mkdirs();
         }
         Part filePart = request.getPart("file");
 		InputStream is = filePart.getInputStream();
 		String fileName = filePart.getSubmittedFileName();
 		Files.copy(is, Paths.get(uploadPath + File.separator + fileName), StandardCopyOption.REPLACE_EXISTING);
 		System.out.println("Path: " + uploadPath);
 	
 		 System.out.println("fileName: " + fileName);
 		
 		
     
		///- file upload end ///
  		
		String name = request.getParameter("name"); //1
		String email = request.getParameter("email");//2
		Long mobile = Long.parseLong(request.getParameter("mobile")); //3
		String gender = request.getParameter("gender");//4
		String address = request.getParameter("address");//5
		String state = request.getParameter("state");//6
		String city = request.getParameter("city");//7
		int zip = Integer.parseInt(request.getParameter("zip"));//8
		String about = request.getParameter("about");//9
		
		 
		 
		
		System.out.println(name);
		System.out.println(email);
		System.out.println(mobile);
		System.out.println(gender);
		System.out.println(address);
		System.out.println(state);
		System.out.println(city);
		System.out.println(zip);
		System.out.println(about);
		CrimeModel crime = new CrimeModel();
		try {	
			System.out.println("inside crime servlet try");
			crime.setName(name);
			crime.setEmail(email);
			crime.setMobile(mobile);
			crime.setGender(gender);
			crime.setAddress(address);
			crime.setState(state);
			crime.setCity(city);
			crime.setZip(zip);
			crime.setAbout(about);
			crime.setFileName(fileName);
			crime.setPath(uploadPath);
			
		}catch (Exception ex) {
			System.out.println("inside crime catch block");
			ex.printStackTrace();
			System.out.println(ex);
		}try {
			System.out.println("inside crime servlet try1");
			int status = AddCrime.SaveCrime(crime);
			if(status > 0) {
				System.out.println("inside  save if  block");
				response.sendRedirect("Crime.jsp");
			}else {
				System.out.println("inside  save else  block");
			}
		}catch (Exception ex) {
			System.out.println("inside crime catch2 block");
			ex.printStackTrace();
			System.out.println(ex);
		}
  		
	}

}
