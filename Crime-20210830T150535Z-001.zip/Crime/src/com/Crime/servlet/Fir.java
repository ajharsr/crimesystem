package com.Crime.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.Crime.model.Firmodel;
import com.Crime.service.AddFir;


@WebServlet("/Fir")
public class Fir extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		String name = request.getParameter("name");
		String fname = request.getParameter("fname");
		String lname = request.getParameter("lname");
		String address = request.getParameter("address");
		String gender = request.getParameter("gender");
		String state = request.getParameter("state");
		String city = request.getParameter("city");
		String dob = request.getParameter("dob");
		int pincode = Integer.parseInt(request.getParameter("pincode"));
		String type = request.getParameter("type");
		String email = request.getParameter("email");
		long  mobile = Long.parseLong(request.getParameter("mobile"));
	    String others = request.getParameter("others");
	    
	    // console check 
	    System.out.println(name);
	    System.out.println(fname);
	    System.out.println(lname);
	    System.out.println(address);
	    System.out.println(gender);
	    System.out.println(state);
	    System.out.println(city);
	    System.out.println(dob);
	    System.out.println(pincode);
	    System.out.println(type);
	    System.out.println(email);
	    System.out.println(others);
	    
	    Firmodel fm = new Firmodel();
	    try {
	    	System.out.println("inside fir try block");
	    	fm.setName(name);
	    	fm.setFname(fname);
	    	fm.setLname(lname);
	    	fm.setAddress(address);
	    	fm.setGender(gender);
	    	
	    	fm.setState(state);
	    	fm.setCity(city);
	    	fm.setDob(dob);
	    	fm.setPincode(pincode);
	    	fm.setType(type);
	    	
	    	fm.setEmail(email);
	    	fm.setMobile(mobile);
	    	fm.setOthers(others);
	    	
	    }catch (Exception e) {
	    	System.out.println("inside fir catch block");
			e.printStackTrace();
			System.out.println(e);
		}try {
			System.out.println("inside fir try2 block");
			int status = AddFir.saveFir(fm);
			if(status > 0) {
				 System.out.println("inside  savefir if  block");
				 request.getRequestDispatcher("Fir.jsp").include(request, response);
			}else {
				System.out.println("inside  savefir if  block");
				 request.getRequestDispatcher("sigininerror.html.html").include(request, response);
			}
			
		}catch (Exception e) {
			System.out.println("inside fir catch2 block");
			e.printStackTrace();
			System.out.println(e);
		}
	    
	    
	    
	    
	}
}
