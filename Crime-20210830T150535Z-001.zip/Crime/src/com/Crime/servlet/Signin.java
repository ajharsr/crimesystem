package com.Crime.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.Crime.dao.SessionDao;
import com.Crime.model.Registration;
import com.Crime.service.LoginValdition;
import com.Crime.util.DbConnection;

@WebServlet("/Signin")
public class Signin extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out = response.getWriter();
		System.out.println("inside do post method");
		String email = request.getParameter("email");
		String password = request.getParameter("password");
		try {
			System.out.println("Inside loginservlet try block");
			if (LoginValdition.LoginValdition(email, password)) {
				// fetch user by email
				try {
					SessionDao dao = new SessionDao(DbConnection.GetConnection());
					Registration registration = dao.getUserByEmail(email);
					if (registration == null) {

					} else {
						HttpSession s = request.getSession();
						s.setAttribute("currentuser", registration);
						response.sendRedirect("Menu.jsp");
						response.sendRedirect("ViewCrimnal.jsp");
						response.sendRedirect("Crimnal.jsp");
						response.sendRedirect("View_fir.jsp");
						response.sendRedirect("viewfir.jsp");
						response.sendRedirect("EditCrimeView.jsp");
						response.sendRedirect("Fir.jsp");
						response.sendRedirect("view.jsp");
						response.sendRedirect("SearchResult.jsp");
					}

				} catch (Exception e) {
					e.printStackTrace();
					System.err.println(e);
				}
				System.out.println(email);
				response.sendRedirect("Menu.jsp");
			} else {
				response.sendRedirect("sigininerror.html");
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.err.println(e);
		}
	}

}
