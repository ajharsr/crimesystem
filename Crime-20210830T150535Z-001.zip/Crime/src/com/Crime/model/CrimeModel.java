package com.Crime.model;

public class CrimeModel {
private long id;
private String name;
private String email;
private long mobile;
private String gender;
private String address;
private String state;
private String city;
private int zip;
private String about;
private String fileName;
private String path;




public CrimeModel() {
	super();
}
public CrimeModel(String name, String email, long mobile, String gender, String address, String state, String city,
		int zip, String about, String fileName, String path) {
	super();
	this.name = name;
	this.email = email;
	this.mobile = mobile;
	this.gender = gender;
	this.address = address;
	this.state = state;
	this.city = city;
	this.zip = zip;
	this.about = about;
	this.fileName = fileName;
	this.path = path;
}
public CrimeModel(long id, String name, String email, long mobile, String gender, String address, String state,
		String city, int zip, String about, String fileName, String path) {
	super();
	this.id = id;
	this.name = name;
	this.email = email;
	this.mobile = mobile;
	this.gender = gender;
	this.address = address;
	this.state = state;
	this.city = city;
	this.zip = zip;
	this.about = about;
	this.fileName = fileName;
	this.path = path;
}
public long getId() {
	return id;
}
public void setId(long id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public long getMobile() {
	return mobile;
}
public void setMobile(long mobile) {
	this.mobile = mobile;
}
public String getGender() {
	return gender;
}
public void setGender(String gender) {
	this.gender = gender;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public String getState() {
	return state;
}
public void setState(String state) {
	this.state = state;
}
public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
}
public int getZip() {
	return zip;
}
public void setZip(int zip) {
	this.zip = zip;
}
public String getAbout() {
	return about;
}
public void setAbout(String about) {
	this.about = about;
}
public String getFileName() {
	return fileName;
}
public void setFileName(String fileName) {
	this.fileName = fileName;
}
public String getPath() {
	return path;
}
public void setPath(String path) {
	this.path = path;
}







}
