package com.Crime.model;

public class Firmodel {
	private long id;
	private String name;
	private String fname;
	private String lname;
	private String address;
	private String gender;
	private String state;
	private String city;
	private String dob;
	private int pincode;
	private String type;
	private String email;
	private long mobile;
	private String others;
	
	public Firmodel() {
		super();
	}
	public Firmodel(String name, String fname, String lname, String address, String gender, String state, String city,
			String dob, int pincode, String type, String email, long mobile, String others) {
		super();
		this.name = name;
		this.fname = fname;
		this.lname = lname;
		this.address = address;
		this.gender = gender;
		this.state = state;
		this.city = city;
		this.dob = dob;
		this.pincode = pincode;
		this.type = type;
		this.email = email;
		this.mobile = mobile;
		this.others = others;
	}
	public Firmodel(long id, String name, String fname, String lname, String address, String gender, String state,
			String city, String dob, int pincode, String type, String email, long mobile, String others) {
		super();
		this.id = id;
		this.name = name;
		this.fname = fname;
		this.lname = lname;
		this.address = address;
		this.gender = gender;
		this.state = state;
		this.city = city;
		this.dob = dob;
		this.pincode = pincode;
		this.type = type;
		this.email = email;
		this.mobile = mobile;
		this.others = others;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public int getPincode() {
		return pincode;
	}
	public void setPincode(int pincode) {
		this.pincode = pincode;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public long getMobile() {
		return mobile;
	}
	public void setMobile(long mobile) {
		this.mobile = mobile;
	}
	public String getOthers() {
		return others;
	}
	public void setOthers(String others) {
		this.others = others;
	}
	
	
	
	

}
