package com.Crime.constant;

public class Constant {

	// --Driver connection--//

	public final static String DRIVER = "com.mysql.cj.jdbc.Driver";
	public static final String URL = "jdbc:mysql://localhost:3306/cis";
	public static final String USERNAME = "root";
	public static final String PASSWORD = "abcd1234";
	// --Driver connection End --//
	
	// -- db query--//
	public static final String REGISTER ="insert into register(name,email,password,cpassword)values(?,?,?,?)";
	public static final String SIGININ 	= "select * from register where email=? and password=? ";
	public static final String SESSION = "select * from register where email=?"; 
	public static final String FIR = "insert into fir (name,fname,lname,address,gender,state,city,dob,pincode,type,email,mobile,others)values(?,?,?,?,?,?,?,?,?,?,?,?,?)";
	
	public static final String VIEWCRIME = "select * from crime where email=?";
	public static final String VIEWFIR = "select * from fir where email=?";
	public static final String crime ="insert into crime(name,email,mobile,gender,address,state,city,zip,about,filename,path)values(?,?,?,?,?,?,?,?,?,?,?)";
	public static final String UPDATECRIME ="update crime set name=?,mobile=?,gender=?,address=?,state=?,city=?,zip=?,about=?,filename=?,path=? where email=?";
	
}
